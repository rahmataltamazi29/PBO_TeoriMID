class Inheritance{
	String nama;
	public int tiperumah;
	public int pemakaian;
	public int bayar;
	public int totalharga;	
}